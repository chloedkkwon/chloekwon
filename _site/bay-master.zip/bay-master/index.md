---
layout: home
profile_picture:
  src: /assets/img/profile-pic.jpg
  alt: website picture
---

<p>
  Welcome! This site serves as an example for the Bay Jekyll theme. Bay is a very simple and minimal theme, directly inspired by Dan Grover's <a href="http://dangrover.com">website</a>.
</p>

<p>
  You can find the source code and the instructions on <a href="https://github.com/eliottvincent/bay">GitHub</a>.
</p>
